<!DOCTYPE html>
<html>
    <head>
        <title>flight booking</title>
    </head>
    <style>
        body{
            background-image:url("btp.jpg");
            background-size:cover;
            background-repeat:no-repeat;
            align-content:center;
            display:flex;
            flex-direction:column;
            
        }
        input{
            margin-left:300px;
            margin-top:20px;
            width:500px;
            height:30px;
            
        }
        div input{
            margin-left:300px;
            margin-top:20px;
            width:500px;
            height:30px;
            float:left;
        }
        a{
            font-size:20px;
            color:red;
        }
        </style>
 
<body>
    <a href='ap.php'>back</a>
   <?php /*<div><label for="r">one way</label>
<input type="radio" value="source" id="r" class="rad">
<label for="s">multiple city</label>
<input type="radio" value="source" id="s" class="rad">
<label for="t">other</label>
<input type="radio" value="source" id="t" class="rad">
    </div>*/?>


<input type="text" value="source" id="a">
<input type="text" value="destination" id="a">

</body>
<html>