<?php
$name=$_POST["name"];
$number=$_POST["no"];
$conn=new mysqli("localhost","root","","emp");
session_start();
if(mysqli_connect_error())
{
    echo "failed";
}
else
{
$sql=mysqli_query($conn,"SELECT * FROM studs WHERE Username='$name'");
$result=mysqli_fetch_array($sql);
    
     if(empty($name))
     echo " username cannot be empty";
    else if(empty($result))
    echo "no such account found";
    else if($number!=$result['Passwd'])
    echo "wrong password";
    
    else
    {   $_SESSION['user']=$name;
        $_SESSION['status']=1;
        header('location:ap.php');
        

    }
}
$conn->close();
?>