<!DOCTYPE html>
<html>
<head>
<title>home page</title>
<style>
body{
    background-image:url("btp.jpg");
    background-size:cover;
    background-repeat:no-repeat;
}
marquee{
    font-size:25px;
    color:blue;
    

    
}
ul{
    font-size:30px;
    color:gold;
    display:block;
    float:left;
    margin:20px;
    margin-top:40px;
}
ul li{
    font-size:30px;
    color:red;
    display:none;
}
ul:hover{
    color:white;
}
ul:hover li{
    display:block;
}
ul #a{
    margin-left:1000px;
    color:red;
}
#image{
    height:200px;
    width:400px;
    z-index: -1;
}
#at{
    color:gold;
}
</style>
</head>
<body>

<ul>Book Tickets
<li>
<a  href="Booking.php" > Flight</a>
</li>
<li>
Railway
<li>
Bus
</li>
</ul>
<ul>My Bookings
<li>
book
</li>
<li>
view
<li>
more
</li>
</ul><ul>Schedule
<li>
book
</li>
<li>
view
<li>
more
</li>
</ul>
<ul>Status
<li>
book
</li>
<li>
view
<li>
more
</li>
</ul>
<ul id="a">
    
    <a href='fld.php' >login</a>
</ul>
<marquee>
    <img src="air.jpg" id="image"></marquee>
    <script>
        alert("book flight and train tickets with latest offers!!!!!")
    </script>

</body>