<!DOCTYPE html>
<html>
    <head>
        <title>dtabase connect</title>
    </head>
    <body>
        <form action="data.php" method="POST">
        <label for="a">Username</label>
            <input type="text" name="name" id="a"> 
            <label for="b">Password</label>
            <input type="password" name="no" id="b">
            <input type="submit" value="Login">
    </form>
   <a href="PasswordRecovery.php">Forgot Password</a>
     <?php
     /*session_start();
     if(isset($_SESSION['abc']))
     {
    if($_GET['logout']==='true'){
    echo "you have sucessfully logged out";
     }
    }
    session_destroy();*/
     ?>
     
     <h1><a href="f.html">signup</a></h1>
    </body>
    
</html>