<?php
$name=$_POST["dat"];
$number=$_POST["no"];
$contact=$_POST["contact"];
$e=$_POST["mail"];
$cp=$_POST["noc"];
$conn=new mysqli("localhost","root","","emp");
$sqln=mysqli_query($conn,"SELECT * FROM studs WHERE Username='$name'");
$sqlc=mysqli_query($conn,"SELECT * FROM studs WHERE Contact='$contact'");
$sqle=mysqli_query($conn,"SELECT * FROM studs WHERE Email='$e'");
$resultn=mysqli_fetch_array($sqln);
$resultc=mysqli_fetch_array($sqlc);
$resulte=mysqli_fetch_array($sqle);
if(mysqli_connect_error())
{  
    echo "failed";
}
else if(empty($name)||empty($number)||empty($contact)||empty($e))
echo "please fill all the columns  ";
else if(!empty($resultn))
{
    echo "Username already exists,try another";
}
else if(!empty($resultc))
{
    echo "the contact number is already used";
}
else if(!empty($resulte))
{
    echo "e-mail id already used,try another";
}
else if($number!=$cp)
{
    echo "password doesnt match,please confirm your password";
}
else
{
$sql="INSERT INTO studs(Username,Passwd,Contact,Email) VALUES('".$name."','".$number."',$contact,'".$e."')";
if($conn->query($sql))
{
echo "your account has been registered" ;
echo "<a href='fld.php'>go to login page</a>";
echo "</br>";
}
else
{
echo "failed query";
}
}
$conn->close();
?>