<!DOCTYPE html>
<html>
<head>
<title>home page</title>
<style>
body{
    background-image:url("btp.jpg");
    background-size:contain;
    background-repeat:no-repeat;
}
marquee{
    font-size:25px;
    color:blue;
    

    
}
ul{
    font-size:30px;
    color:gold;
    display:block;
    float:left;
    margin:20px;
    margin-top:40px;
    z-index:1;
}
ul li{
    font-size:30px;
    color:red;
    display:none;
    z-index:1;
}
ul:hover{
    color:white;
}
ul:hover li{
    display:block;
}
ul #a{
    margin-left:1000px;
}
img{
    height:200px;
    width:400px;
    z-index:-1;
    position:relative;
    width:600px;
    height:700px;
}
</style>
</head>
<body>
<marquee direction="right">
    <?php
session_start();
echo "Welcome  ".$_SESSION['user'];
$_SESSION['abc']='adsdsgsg';
?>
</marquee>
<ul >Book Tickets
<li>
<a  href="Booking.php"> Flight</a>
</li>
<li>
Railway
<li>
Bus
</li>
</ul>
<ul>My Bookings
<li>
book
</li>
<li>
view
<li>
more
</li>
</ul><ul>Schedule
<li>
book
</li>
<li>
view
<li>
more
</li>
</ul>
<ul>Status
<li>
book
</li>
<li>
view
<li>
more
</li>
</ul>
<ul id="a">
    <?php
    echo "<a href='fld.php?logout=true' >logout</a>";
    ?>
</ul>
<img src="p12.jpg" >
    <script>
        alert("book flight and train tickets with latest offers!!!!!")
    </script>
    

</body>